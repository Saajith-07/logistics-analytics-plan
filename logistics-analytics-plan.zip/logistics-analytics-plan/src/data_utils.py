"""Data loading and cleaning for the DataCo Smart Supply Chain scenario.

Real data : https://data.mendeley.com/datasets/8gx2fvg2k6/5  (DOI 10.17632/8gx2fvg2k6.5)
            Save DataCoSupplyChainDataset.csv into ./data/
If the file is missing, a synthetic dataset with the same key columns is generated
so the whole pipeline can be demonstrated end-to-end.
"""
from pathlib import Path
import numpy as np
import pandas as pd

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "DataCoSupplyChainDataset.csv"

KEEP = [
    "order date (DateOrders)", "Days for shipping (real)", "Days for shipment (scheduled)",
    "Late_delivery_risk", "Shipping Mode", "Order Region", "Market", "Customer Segment",
    "Category Name", "Order Item Quantity", "Sales", "Order Item Discount Rate",
    "Order Profit Per Order",
]


def load_data(path: Path = DATA_PATH) -> pd.DataFrame:
    if path.exists():
        df = pd.read_csv(path, encoding="latin-1")      # file is not UTF-8
        print(f"Loaded real DataCo data: {df.shape}")
        return df[KEEP].copy()
    print("Real dataset not found -> using synthetic data (same schema).")
    return make_synthetic()


def make_synthetic(n: int = 30000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    modes = {"Standard Class": (4, 4), "Second Class": (4, 2), "First Class": (1, 1), "Same Day": (0, 0)}
    mode = rng.choice(list(modes), n, p=[0.6, 0.2, 0.15, 0.05])
    sched = np.array([modes[m][0] for m in mode])
    extra = np.where(mode == "First Class", rng.choice([0, 1, 2], n, p=[.05, .9, .05]),
                     rng.choice([-1, 0, 1, 2], n, p=[.3, .4, .2, .1]))
    real = np.clip(sched + extra, 0, None)
    dates = pd.Timestamp("2015-01-01") + pd.to_timedelta(rng.integers(0, 1095, n), unit="D")
    qty = rng.integers(1, 6, n)
    price = rng.choice([30, 60, 120, 250], n)
    return pd.DataFrame({
        "order date (DateOrders)": dates,
        "Days for shipping (real)": real,
        "Days for shipment (scheduled)": sched,
        "Late_delivery_risk": (real > sched).astype(int),
        "Shipping Mode": mode,
        "Order Region": rng.choice(["Western Europe", "Central America", "South Asia", "US East", "Oceania"], n),
        "Market": rng.choice(["Europe", "LATAM", "Pacific Asia", "USCA", "Africa"], n),
        "Customer Segment": rng.choice(["Consumer", "Corporate", "Home Office"], n, p=[.52, .30, .18]),
        "Category Name": rng.choice(["Cleats", "Men's Footwear", "Women's Apparel", "Electronics", "Fishing"], n),
        "Order Item Quantity": qty,
        "Sales": price * qty,
        "Order Item Discount Rate": rng.uniform(0, .25, n).round(2),
        "Order Profit Per Order": (price * qty * rng.normal(.12, .15, n)).round(2),
    })


def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["order_date"] = pd.to_datetime(df["order date (DateOrders)"], errors="coerce")
    df = df.drop(columns="order date (DateOrders)").dropna(subset=["order_date"])
    df = df.drop_duplicates()
    for c in df.select_dtypes("object"):
        df[c] = df[c].str.strip()
    df = df[df["Sales"] > 0]
    df["delay_days"] = df["Days for shipping (real)"] - df["Days for shipment (scheduled)"]
    df["month"] = df["order_date"].dt.month
    df["dow"] = df["order_date"].dt.dayofweek
    return df.reset_index(drop=True)
