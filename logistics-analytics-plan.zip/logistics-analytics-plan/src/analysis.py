"""End-to-end logistics analytics pipeline.

Run:  python src/analysis.py
Outputs (PNG + CSV) are written to ./outputs
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingRegressor, HistGradientBoostingClassifier
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_percentage_error, roc_auc_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from data_utils import load_data, clean
from routing import solve_cvrp, naive_distance

OUT = Path(__file__).resolve().parents[1] / "outputs"
OUT.mkdir(exist_ok=True)
SEED = 42


# ---------- 1. KPIs ----------------------------------------------------------
def compute_kpis(df):
    """KPI 1: On-time delivery rate | KPI 2: Avg delay (days) | KPI 3: Profit margin."""
    return pd.Series({
        "on_time_delivery_rate_%": 100 * (1 - df["Late_delivery_risk"].mean()),
        "avg_delay_days": df["delay_days"].mean(),
        "profit_margin_%": 100 * df["Order Profit Per Order"].sum() / df["Sales"].sum(),
    }).round(2)


def kpi_by(df, col):
    return (df.groupby(col)
              .agg(orders=("Sales", "size"),
                   late_rate=("Late_delivery_risk", "mean"),
                   avg_delay=("delay_days", "mean"))
              .sort_values("late_rate", ascending=False).round(3))


# ---------- 2. Predictive model: late-delivery risk (classification) ---------
def train_late_model(df):
    # Leakage guard: 'Days for shipping (real)' is only known AFTER delivery.
    cat = ["Shipping Mode", "Order Region", "Market", "Customer Segment", "Category Name"]
    num = ["Days for shipment (scheduled)", "Order Item Quantity", "Sales",
           "Order Item Discount Rate", "month", "dow"]
    X, y = df[cat + num], df["Late_delivery_risk"]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.2, stratify=y, random_state=SEED)
    pre = ColumnTransformer([("c", OneHotEncoder(handle_unknown="ignore"), cat),
                             ("n", StandardScaler(), num)])
    model = Pipeline([("pre", pre), ("clf", HistGradientBoostingClassifier(random_state=SEED))])
    model.fit(Xtr, ytr)
    proba = model.predict_proba(Xte)[:, 1]
    print(f"\n[Late-delivery model] ROC-AUC = {roc_auc_score(yte, proba):.3f}")
    print(classification_report(yte, proba > .5, digits=3))
    return model


# ---------- 3. Demand forecasting (regression) -------------------------------
def forecast_demand(df, horizon=8):
    w = (df.set_index("order_date")["Order Item Quantity"].resample("W").sum().rename("units").to_frame())
    for lag in (1, 2, 3, 4, 52):
        w[f"lag{lag}"] = w["units"].shift(lag)
    w["roll4"] = w["units"].shift(1).rolling(4).mean()
    w["woy"] = w.index.isocalendar().week.astype(int)
    w = w.dropna()
    train, test = w.iloc[:-horizon], w.iloc[-horizon:]
    feats = [c for c in w.columns if c != "units"]
    base = LinearRegression().fit(train[feats], train["units"])
    gbr = GradientBoostingRegressor(random_state=SEED).fit(train[feats], train["units"])
    for name, m in [("Linear regression", base), ("Gradient boosting", gbr)]:
        mape = mean_absolute_percentage_error(test["units"], m.predict(test[feats]))
        print(f"[Demand forecast] {name:18s} MAPE = {100*mape:.1f}%")
    return w, gbr, feats, test


# ---------- 4. Inventory policy (safety stock / reorder point) ----------------
def inventory_policy(df, lead_time_wk=1, service_z=1.65):
    wk = (df.groupby(["Category Name", pd.Grouper(key="order_date", freq="W")])["Order Item Quantity"]
            .sum().reset_index())
    g = wk.groupby("Category Name")["Order Item Quantity"].agg(mean_d="mean", std_d="std")
    g["safety_stock"] = service_z * g["std_d"] * np.sqrt(lead_time_wk)       # ~95% service level
    g["reorder_point"] = g["mean_d"] * lead_time_wk + g["safety_stock"]
    return g.round(0)


# ---------- 5. Clustering: segment regions by service profile -----------------
def cluster_regions(df, k=3):
    prof = df.groupby("Order Region").agg(
        late_rate=("Late_delivery_risk", "mean"), avg_delay=("delay_days", "mean"),
        avg_sales=("Sales", "mean"), margin=("Order Profit Per Order", "mean"))
    Z = StandardScaler().fit_transform(prof)
    prof["cluster"] = KMeans(n_clusters=min(k, len(prof)), n_init=10, random_state=SEED).fit_predict(Z)
    return prof.round(3)


# ---------- 6. Route optimisation (OR-Tools CVRP) -----------------------------
def routing_demo(n_customers=30):
    rng = np.random.default_rng(SEED)
    coords = np.vstack([[50, 50], rng.uniform(0, 100, (n_customers, 2))])
    demands = np.r_[0, rng.integers(1, 9, n_customers)]
    routes, opt = solve_cvrp(coords, demands, n_vehicles=5, capacity=60)
    naive = naive_distance(coords, range(1, n_customers + 1))
    print(f"[Routing] naive single-truck distance: {naive:.0f} | optimised {len(routes)}-truck total: {opt:.0f}")
    return coords, routes


def main():
    df = clean(load_data())
    print("\nKPIs:\n", compute_kpis(df))
    by_mode = kpi_by(df, "Shipping Mode"); print("\nBy shipping mode:\n", by_mode)
    by_mode.to_csv(OUT / "kpi_by_shipping_mode.csv")

    train_late_model(df)
    forecast_demand(df)
    print("\nInventory policy:\n", inventory_policy(df))
    print("\nRegion clusters:\n", cluster_regions(df))

    coords, routes = routing_demo()
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
    by_mode["late_rate"].plot.bar(ax=ax[0], color="#1F4E79"); ax[0].set_title("Late-delivery rate by shipping mode")
    ax[0].set_ylabel("Late rate")
    for r in routes:
        if len(r) > 2: ax[1].plot(*coords[r].T, marker="o", ms=3)
    ax[1].scatter(*coords[0], c="k", marker="s", s=60); ax[1].set_title("Optimised delivery routes (OR-Tools)")
    plt.tight_layout(); plt.savefig(OUT / "results.png", dpi=150)
    print(f"\nSaved figure -> {OUT/'results.png'}")


if __name__ == "__main__":
    main()
