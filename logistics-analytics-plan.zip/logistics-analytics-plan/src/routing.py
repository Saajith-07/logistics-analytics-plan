"""Capacitated vehicle routing (CVRP) with Google OR-Tools - last-mile route optimisation demo."""
import numpy as np
from ortools.constraint_solver import pywrapcp, routing_enums_pb2


def solve_cvrp(coords, demands, n_vehicles=4, capacity=40, time_limit_s=5):
    """coords[0] is the depot. Returns (routes, total_distance)."""
    pts = np.asarray(coords)
    dist = (np.sqrt(((pts[:, None] - pts[None]) ** 2).sum(-1)) * 1000).astype(int)
    mgr = pywrapcp.RoutingIndexManager(len(pts), n_vehicles, 0)
    routing = pywrapcp.RoutingModel(mgr)
    cb = routing.RegisterTransitCallback(lambda i, j: int(dist[mgr.IndexToNode(i)][mgr.IndexToNode(j)]))
    routing.SetArcCostEvaluatorOfAllVehicles(cb)
    dem = routing.RegisterUnaryTransitCallback(lambda i: int(demands[mgr.IndexToNode(i)]))
    routing.AddDimensionWithVehicleCapacity(dem, 0, [capacity] * n_vehicles, True, "Capacity")
    p = pywrapcp.DefaultRoutingSearchParameters()
    p.first_solution_strategy = routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    p.local_search_metaheuristic = routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
    p.time_limit.seconds = time_limit_s
    sol = routing.SolveWithParameters(p)
    if sol is None:
        return [], None
    routes, total = [], 0
    for v in range(n_vehicles):
        i, r = routing.Start(v), []
        while not routing.IsEnd(i):
            r.append(mgr.IndexToNode(i))
            nxt = sol.Value(routing.NextVar(i))
            total += routing.GetArcCostForVehicle(i, nxt, v)
            i = nxt
        r.append(0)
        routes.append(r)
    return routes, total / 1000


def naive_distance(coords, order):
    pts = np.asarray(coords)
    path = [0] + list(order) + [0]
    return float(sum(np.linalg.norm(pts[a] - pts[b]) for a, b in zip(path, path[1:])))
