# Logistics Analytics Strategic Plan – Late-Delivery Risk, Demand Forecasting & Route Optimisation

Strategic planning project for a global omni-channel retailer (modelled on the public
**DataCo Smart Supply Chain** dataset). Illustrates an end-to-end Python workflow:

1. Data collection & cleaning (`src/data_utils.py`)
2. KPI computation (on-time delivery rate, average delay, profit margin)
3. Classification – late-delivery risk prediction
4. Regression – weekly demand forecasting
5. Inventory policy – safety stock / reorder point
6. Clustering – regional service profiles
7. Optimisation – capacitated vehicle routing with OR-Tools (`src/routing.py`)

## Run
```bash
pip install -r requirements.txt
# optional: download DataCoSupplyChainDataset.csv from
# https://data.mendeley.com/datasets/8gx2fvg2k6/5 into ./data/
python src/analysis.py
```
Without the CSV, a synthetic dataset with the same schema is generated, so results
shown without the real file are **illustrative only**.

## Data
Constante, F., Silva, F., Pereira, A. (2019). *DataCo Smart Supply Chain for Big Data Analysis*.
Mendeley Data, V5. DOI: 10.17632/8gx2fvg2k6.5
