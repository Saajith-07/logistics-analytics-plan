const fs = require('fs');
const D = require('docx');
const { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType,
  ShadingType, BorderStyle, AlignmentType, LevelFormat, ImageRun, Footer, PageNumber, PageBreak } = D;

const W = 9026, BLUE = '1F4E79';
const h1 = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] });
const h2 = t => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] });
const p = (t, o = {}) => new Paragraph({ spacing: { after: 120 }, ...o, children: Array.isArray(t) ? t : [new TextRun(t)] });
const b = (t, lvl = 0) => new Paragraph({ numbering: { reference: 'bul', level: lvl }, spacing: { after: 60 },
  children: Array.isArray(t) ? t : [new TextRun(t)] });
const bold = t => new TextRun({ text: t, bold: true });
const cap = t => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: t, italics: true, size: 18, color: '555555' })] });

const bd = { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB' };
const borders = { top: bd, bottom: bd, left: bd, right: bd };
function table(widths, rows, headFill = BLUE) {
  return new Table({
    width: { size: widths.reduce((a, c) => a + c, 0), type: WidthType.DXA }, columnWidths: widths,
    rows: rows.map((r, i) => new TableRow({ tableHeader: i === 0, children: r.map((c, j) => new TableCell({
      borders, width: { size: widths[j], type: WidthType.DXA },
      shading: i === 0 ? { fill: headFill, type: ShadingType.CLEAR, color: 'auto' } : (i % 2 ? undefined : { fill: 'F2F6FA', type: ShadingType.CLEAR, color: 'auto' }),
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      children: [new Paragraph({ children: [new TextRun({ text: c, bold: i === 0, color: i === 0 ? 'FFFFFF' : '000000', size: 19 })] })]
    })) }))
  });
}
function code(lines) {
  return lines.split('\n').map((l, i, a) => new Paragraph({
    spacing: { after: 0, line: 240 },
    shading: { fill: 'F4F4F4', type: ShadingType.CLEAR, color: 'auto' },
    border: { left: { style: BorderStyle.SINGLE, size: 12, color: BLUE, space: 6 } },
    indent: { left: 120 },
    children: [new TextRun({ text: l === '' ? ' ' : l, font: 'Courier New', size: 17 })]
  })).concat([new Paragraph({ spacing: { after: 160 }, children: [] })]);
}

const C = {};
C.load = `df = pd.read_csv("data/DataCoSupplyChainDataset.csv", encoding="latin-1")
df["order_date"] = pd.to_datetime(df["order date (DateOrders)"])
df = df.drop_duplicates()
df = df[df["Sales"] > 0]
df["delay_days"] = df["Days for shipping (real)"] - df["Days for shipment (scheduled)"]`;
C.kpi = `def compute_kpis(df):
    return pd.Series({
        "on_time_delivery_rate_%": 100 * (1 - df["Late_delivery_risk"].mean()),
        "avg_delay_days": df["delay_days"].mean(),
        "profit_margin_%": 100 * df["Order Profit Per Order"].sum() / df["Sales"].sum(),
    })
df.groupby("Shipping Mode")["Late_delivery_risk"].mean().sort_values()`;
C.clf = `# Leakage guard: use only information known AT ORDER TIME
cat = ["Shipping Mode", "Order Region", "Market", "Customer Segment", "Category Name"]
num = ["Days for shipment (scheduled)", "Order Item Quantity", "Sales", "month", "dow"]
Xtr, Xte, ytr, yte = train_test_split(df[cat+num], df["Late_delivery_risk"],
                                      test_size=.2, stratify=df["Late_delivery_risk"])
pre = ColumnTransformer([("c", OneHotEncoder(handle_unknown="ignore"), cat),
                         ("n", StandardScaler(), num)])
model = Pipeline([("pre", pre), ("clf", HistGradientBoostingClassifier())]).fit(Xtr, ytr)
print(roc_auc_score(yte, model.predict_proba(Xte)[:, 1]))`;
C.fc = `weekly = df.set_index("order_date")["Order Item Quantity"].resample("W").sum().to_frame("units")
for lag in (1, 2, 3, 4, 52): weekly[f"lag{lag}"] = weekly["units"].shift(lag)
weekly["roll4"] = weekly["units"].shift(1).rolling(4).mean()
train, test = weekly.dropna().iloc[:-8], weekly.dropna().iloc[-8:]
gbr = GradientBoostingRegressor().fit(train.drop(columns="units"), train["units"])
mape = mean_absolute_percentage_error(test["units"], gbr.predict(test.drop(columns="units")))`;
C.inv = `# Safety stock for ~95% cycle service level (z = 1.65), lead time L weeks
safety_stock  = 1.65 * std_weekly_demand * np.sqrt(L)
reorder_point = mean_weekly_demand * L + safety_stock`;
C.km = `profile = df.groupby("Order Region").agg(late=("Late_delivery_risk","mean"),
                                           delay=("delay_days","mean"),
                                           margin=("Order Profit Per Order","mean"))
profile["cluster"] = KMeans(n_clusters=3, n_init=10).fit_predict(StandardScaler().fit_transform(profile))`;
C.vrp = `manager = pywrapcp.RoutingIndexManager(n_nodes, n_vehicles, depot=0)
routing = pywrapcp.RoutingModel(manager)
routing.SetArcCostEvaluatorOfAllVehicles(routing.RegisterTransitCallback(distance_cb))
routing.AddDimensionWithVehicleCapacity(routing.RegisterUnaryTransitCallback(demand_cb),
                                        0, [capacity]*n_vehicles, True, "Capacity")
params = pywrapcp.DefaultRoutingSearchParameters()
params.first_solution_strategy = FirstSolutionStrategy.PATH_CHEAPEST_ARC
params.local_search_metaheuristic = LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
solution = routing.SolveWithParameters(params)`;

const img = fs.readFileSync('outputs/results.png');
const kids = [];
// ---- Title block
kids.push(new Paragraph({ spacing: { before: 1200, after: 120 }, children: [new TextRun({ text: 'Data-Driven Logistics Optimisation', size: 52, bold: true, color: BLUE })] }));
kids.push(new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text: 'Strategic Planning Report: Late-Delivery Risk, Demand Forecasting and Route Optimisation using Python', size: 28, color: '444444' })] }));
kids.push(new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: BLUE, space: 4 } }, spacing: { after: 240 }, children: [] }));
kids.push(p([bold('Scenario: '), new TextRun('DataCo Global, an omni-channel retailer shipping clothing, sports and electronics supplies worldwide')]));
kids.push(p([bold('Date: '), new TextRun('28 October 2026')]));
kids.push(p([bold('Primary dataset: '), new TextRun('DataCo Smart Supply Chain for Big Data Analysis (Mendeley Data, DOI 10.17632/8gx2fvg2k6.5)')]));
kids.push(p([bold('Code: '), new TextRun('see the accompanying repository (src/analysis.py, src/routing.py, src/data_utils.py)')]));
kids.push(new Paragraph({ children: [new PageBreak()] }));

// ---- Exec summary
kids.push(h1('Executive Summary'));
kids.push(p('Late deliveries, stock-outs and inefficient delivery routes are three of the most expensive and visible failures in logistics. They are linked: poor demand forecasts create the wrong inventory in the wrong place, which forces expensive expedited shipping, which in turn raises late-delivery rates and erodes customer satisfaction.'));
kids.push(p('This report plans an analytics programme in Python that attacks all three problems with one connected workflow: (1) classification to predict which orders are likely to be delivered late, (2) regression-based demand forecasting feeding a safety-stock and reorder-point policy, (3) clustering to segment regions by service profile, and (4) mathematical optimisation (capacitated vehicle routing) to cut last-mile distance. Success is measured with five KPIs: on-time delivery rate, average delivery delay, forecast accuracy (MAPE), inventory service level / stock-out rate, and transport cost per order.'));
kids.push(p([bold('Note on results: '), new TextRun('the figures shown in Section 6 were produced on a synthetic dataset with the same schema as the public data, purely to prove that the code runs end to end. They are not findings about the real DataCo data and should be regenerated once the real CSV is loaded.')]));

// ---- 1 Background
kids.push(h1('1. Background and Research'));
kids.push(h2('1.1 Why logistics analytics matters'));
kids.push(p('Logistics typically accounts for a large share of a retailer\u2019s operating cost, and delivery reliability is a key driver of customer retention. Three decision areas are most amenable to data science: inventory (how much to hold and when to reorder), transportation (which route, mode and carrier), and service-level management (which orders are at risk). An academic study on delivery-time forecasting using this same dataset cites McKinsey estimates that AI in supply chain management can cut forecast errors by 20\u201350% and costs by 10\u201315% (Vestnik DSTU, secondary citation; to be verified against the primary source before any business case relies on it).'));
kids.push(h2('1.2 Public data sources reviewed'));
kids.push(table([2300, 3700, 3026], [
  ['Dataset', 'Content', 'Use in this project'],
  ['DataCo Smart Supply Chain (Mendeley Data / Kaggle)', 'Orders, scheduled vs real shipping days, shipping mode, region, customer segment, sales, profit, late-delivery flag; plus clickstream logs', 'Primary: KPIs, late-delivery classification, demand forecasting, clustering'],
  ['M5 Forecasting (Walmart, Kaggle)', 'Hierarchical daily unit sales with prices and calendar events', 'Benchmark for forecasting methods'],
  ['Olist Brazilian E-Commerce (Kaggle)', 'Orders, delivery timestamps, customer and seller geolocation', 'Optional validation of delivery-delay models'],
  ['Solomon / Homberger VRP benchmarks', 'Standard vehicle-routing instances with known best solutions', 'Validate the routing solver'],
], BLUE));
kids.push(p('', { spacing: { after: 60 } }));
kids.push(p('The DataCo dataset was selected as the primary source because it is free, widely used in published work (including delivery-time forecasting and sales and inventory forecasting studies), and contains both the target variable (Late_delivery_risk) and the commercial fields needed to translate model output into money. Its main limitations are that it is a single company\u2019s simulated/anonymised data, it has no explicit stock-level or vehicle data, and some fields (for example actual shipping days) are only known after delivery, which creates a data-leakage risk that the plan explicitly controls for.'));
kids.push(h2('1.3 Methodological literature'));
kids.push(b([bold('Inventory theory: '), new TextRun('safety stock and reorder-point models under uncertain demand and lead time (Silver, Pyke and Thomas, Inventory and Production Management in Supply Chains).')]));
kids.push(b([bold('Demand forecasting: '), new TextRun('gradient-boosted trees with lag and calendar features performed strongly in the M5 competition (Makridakis et al., 2022), motivating their use over purely classical baselines.')]));
kids.push(b([bold('Vehicle routing: '), new TextRun('the CVRP is NP-hard; metaheuristics such as guided local search give high-quality solutions quickly (Toth and Vigo, The Vehicle Routing Problem; Google OR-Tools).')]));

// ---- 2 Project definition
kids.push(h1('2. Project Definition'));
kids.push(h2('2.1 Logistics scenario'));
kids.push(p('DataCo Global sells clothing, sports equipment and electronics to consumers, corporate and home-office customers across several markets. Orders ship under four service levels (Standard, Second Class, First Class, Same Day). Management has three recurring pain points:'));
kids.push(b([bold('Service reliability: '), new TextRun('a material share of orders arrive later than the scheduled shipping window, and operations learn about it only after the fact.')]));
kids.push(b([bold('Inventory imbalance: '), new TextRun('demand is seasonal and varies by category and market, so stock is simultaneously over- and under-supplied.')]));
kids.push(b([bold('Last-mile cost: '), new TextRun('deliveries from regional hubs are planned manually, producing avoidable distance and vehicle use.')]));
kids.push(h2('2.2 Objectives'));
kids.push(b('O1. Predict at order time which orders are at high risk of late delivery, so operations can intervene (re-route, upgrade mode, notify customer).'));
kids.push(b('O2. Forecast weekly demand per category with lower error than a naive baseline, and convert forecasts into reorder points and safety stock.'));
kids.push(b('O3. Identify groups of regions with similar service/profit profiles to target process improvements.'));
kids.push(b('O4. Quantify the distance and vehicle savings of optimised routes versus a manual baseline.'));
kids.push(b('O5. Deliver a reproducible Python pipeline and a KPI dashboard that decision-makers can refresh monthly.'));
kids.push(h2('2.3 Key Performance Indicators'));
kids.push(table([1900, 3000, 2226, 1900], [
  ['KPI', 'Definition', 'Data fields', 'Target (proposed)'],
  ['On-time delivery rate', '% orders with real shipping days \u2264 scheduled days', 'Days for shipping (real), Days for shipment (scheduled), Late_delivery_risk', '+5 percentage points vs baseline'],
  ['Average delivery delay', 'Mean of (real \u2212 scheduled) days, overall and by mode / region', 'Same as above', 'Reduce by 20%'],
  ['Forecast accuracy (MAPE)', 'Mean absolute percentage error of weekly demand forecast on a held-out period', 'order date, Order Item Quantity', 'Beat seasonal-naive baseline; MAPE < 15%'],
  ['Stock-out rate / service level', '% of demand periods where demand exceeds stock; target cycle service level 95%', 'Derived from forecast + policy simulation', '\u2265 95% service level'],
  ['Transport cost per order', 'Route distance \u00d7 cost per km + vehicle cost, divided by orders delivered', 'Hub/customer coordinates, vehicle parameters', 'Reduce by 15\u201330% in routing pilot'],
], BLUE));
kids.push(p('', { spacing: { after: 60 } }));
kids.push(p('Targets are proposals to be calibrated once baselines are measured in Phase 2; they are not claims about current DataCo performance.'));

// ---- 3 Data science
kids.push(h1('3. How Data Science Applies'));
kids.push(table([1900, 3600, 3526], [
  ['Technique', 'Application', 'Python tools / evaluation'],
  ['Classification', 'Predict Late_delivery_risk from order-time features (mode, region, segment, category, quantity, season)', 'scikit-learn HistGradientBoosting; ROC-AUC, precision/recall, cost-weighted threshold'],
  ['Regression / time series', 'Weekly demand per category using lags, rolling means, calendar features', 'LinearRegression baseline, GradientBoosting; MAPE on rolling-origin split'],
  ['Clustering', 'Group regions/markets by late rate, delay, margin to prioritise interventions', 'KMeans on standardised features; silhouette score'],
  ['Optimisation', 'Capacitated vehicle routing; reorder-point policy under service-level constraint', 'Google OR-Tools; compare to naive route distance'],
  ['Descriptive analytics', 'KPI tracking, delay root-cause analysis (e.g. by shipping mode)', 'pandas groupby, matplotlib'],
], BLUE));
kids.push(p('', { spacing: { after: 60 } }));
kids.push(p('The techniques are chained rather than independent: the clustering identifies where problems concentrate, the classifier flags individual at-risk orders, the forecast sets inventory positions that reduce the need for expediting, and routing lowers the cost of the physical delivery. A key design principle is to use only features available at decision time (no post-delivery fields) in any predictive model.'));

// ---- 4 Roadmap
kids.push(h1('4. Strategic Roadmap'));
kids.push(p('The end-to-end flow has six phases. Durations assume one analyst working part-time; they are planning estimates.'));
kids.push(table([1500, 3400, 2526, 1600], [
  ['Phase', 'Activities', 'Deliverables', 'Duration'],
  ['1. Data collection', 'Download DataCo CSV (latin-1 encoding), document schema, store raw data read-only, set up Git repo and environment', 'Data dictionary, repo, requirements.txt', 'Week 1'],
  ['2. Cleaning and baseline KPIs', 'Parse dates, remove duplicates and invalid sales, handle missing values, engineer delay_days, month, day-of-week; compute baseline KPIs', 'Clean dataset, KPI baseline table', 'Weeks 1\u20132'],
  ['3. Exploratory analysis', 'Late rate by mode/region/segment, seasonality, correlation checks, outlier review; clustering of regions', 'EDA notebook, cluster profiles', 'Weeks 2\u20133'],
  ['4. Predictive modelling', 'Late-risk classifier; demand forecast with time-based validation; leakage checks; hyper-parameter tuning', 'Trained models, evaluation report', 'Weeks 3\u20135'],
  ['5. Optimisation', 'Reorder-point policy; CVRP routing pilot; scenario comparison versus baseline', 'Policy table, route plans, savings estimate', 'Weeks 5\u20136'],
  ['6. Reporting and deployment', 'KPI dashboard, recommendations, monitoring plan (drift, monthly retrain)', 'Final report, dashboard, handover notes', 'Weeks 6\u20137'],
], BLUE));
kids.push(p('', { spacing: { after: 60 } }));
kids.push(h2('Risks and mitigations'));
kids.push(b([bold('Data leakage: '), new TextRun('exclude post-delivery fields from model inputs; validate with time-based splits.')]));
kids.push(b([bold('Class imbalance / threshold choice: '), new TextRun('evaluate with precision-recall and choose the threshold using the cost of a missed late order versus the cost of an unnecessary intervention.')]));
kids.push(b([bold('No real vehicle or stock data: '), new TextRun('routing and inventory results rely on stated assumptions (capacity, lead time, cost per km); treat them as pilots and run sensitivity analysis.')]));
kids.push(b([bold('Generalisability: '), new TextRun('one company\u2019s data; validate on a second dataset (e.g. Olist) before generalising conclusions.')]));

// ---- 5 Code
kids.push(h1('5. Code Illustration'));
kids.push(p('The snippets below are condensed from the working scripts in the repository. Full versions, including imports and a synthetic-data fallback, are in src/.'));
kids.push(h2('5.1 Load and clean'));  kids.push(...code(C.load));
kids.push(h2('5.2 KPI computation'));  kids.push(...code(C.kpi));
kids.push(h2('5.3 Late-delivery classification'));  kids.push(...code(C.clf));
kids.push(h2('5.4 Demand forecasting'));  kids.push(...code(C.fc));
kids.push(h2('5.5 Inventory policy'));  kids.push(...code(C.inv));
kids.push(h2('5.6 Clustering regions'));  kids.push(...code(C.km));
kids.push(h2('5.7 Route optimisation (OR-Tools)'));  kids.push(...code(C.vrp));

// ---- 6 Demo results
kids.push(h1('6. Proof-of-Concept Run'));
kids.push(p('To verify that the pipeline executes end to end, it was run on a 30,000-row synthetic dataset that mimics the DataCo schema. The left panel shows late rate by shipping mode; the right panel shows 30 customers served by five capacity-constrained vehicles. In the synthetic routing demo, the optimised plan covered a total distance of about 545 units versus about 1,528 for a naive single-truck sequence; this compares different setups (five trucks versus one) and only demonstrates that the solver works, not an expected saving.'));
kids.push(new Paragraph({ alignment: AlignmentType.CENTER, children: [new ImageRun({ type: 'png', data: img, transformation: { width: 600, height: 225 }, altText: { title: 'Results', description: 'Late rate by mode and optimised routes', name: 'results' } })] }));
kids.push(cap('Figure 1. Output of src/analysis.py on synthetic data (illustrative only).'));
kids.push(p('Other synthetic-run outputs: demand-forecast MAPE of about 8% (gradient boosting) and a late-delivery classifier ROC-AUC of about 0.68. These reflect the simulated data-generating process, so no business conclusion should be drawn from them.'));

// ---- 7 Conclusion
kids.push(h1('7. Expected Outcomes and Impact on Decision-Making'));
kids.push(b([bold('Proactive service management: '), new TextRun('a risk score at order time lets operations upgrade shipping, prioritise warehouse picking or warn customers before a delay happens, rather than reporting it afterwards.')]));
kids.push(b([bold('Right-sized inventory: '), new TextRun('forecast-driven reorder points and safety stock replace rule-of-thumb buffers, targeting a stated service level at lower working capital.')]));
kids.push(b([bold('Targeted investment: '), new TextRun('region clusters show where carrier renegotiation or hub changes will matter most.')]));
kids.push(b([bold('Lower delivery cost: '), new TextRun('optimised routes reduce distance, fuel and vehicles per delivery, and the same solver can be re-run daily.')]));
kids.push(b([bold('Governance: '), new TextRun('a version-controlled, reproducible pipeline with monitored KPIs lets managers trust, audit and refresh the analysis.')]));
kids.push(p('In conclusion, combining descriptive KPIs, predictive models and optimisation in one Python workflow turns logistics data from a reporting archive into a decision tool. The plan is feasible with free public data and open-source libraries, and the staged roadmap lets the team prove value early (baseline KPIs and the late-risk model) before investing in routing and inventory pilots.'));

// ---- References
kids.push(h1('References'));
const refs = [
  'Constante, F., Silva, F. and Pereira, A. (2019). DataCo Smart Supply Chain for Big Data Analysis. Mendeley Data, V5. DOI: 10.17632/8gx2fvg2k6.5. https://data.mendeley.com/datasets/8gx2fvg2k6/5',
  'Forecasting Delivery Time of Goods in Supply Chains Using Machine Learning Methods. Vestnik of Don State Technical University. https://www.vestnik-donstu.ru/jour/article/view/2400',
  'Forecasting Sales and Inventory in Supply Chain using Machine Learning (MSc research project using the DataCo dataset), National College of Ireland. https://norma.ncirl.ie/7251/2/riandwiputraconfigurationmanual.pdf',
  'Makridakis, S., Spiliotis, E., Assimakopoulos, V. (2022). M5 accuracy competition: Results, findings, and conclusions. International Journal of Forecasting.',
  'Silver, E.A., Pyke, D.F., Thomas, D.J. (2017). Inventory and Production Management in Supply Chains. CRC Press.',
  'Toth, P. and Vigo, D. (2014). Vehicle Routing: Problems, Methods, and Applications. SIAM.',
  'Google OR-Tools documentation, Vehicle Routing. https://developers.google.com/optimization/routing',
  'Pedregosa, F. et al. (2011). Scikit-learn: Machine Learning in Python. JMLR 12.',
];
refs.forEach(r => kids.push(new Paragraph({ numbering: { reference: 'num', level: 0 }, spacing: { after: 80 }, children: [new TextRun({ text: r, size: 20 })] })));

const doc = new Document({
  creator: 'Logistics Analytics Project', title: 'Data-Driven Logistics Optimisation - Strategic Planning Report',
  styles: {
    default: { document: { run: { font: 'Calibri', size: 22 } } },
    paragraphStyles: [
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 32, bold: true, color: BLUE, font: 'Calibri' }, paragraph: { spacing: { before: 320, after: 140 }, outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 26, bold: true, color: '2E75B6', font: 'Calibri' }, paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 1 } },
    ]
  },
  numbering: { config: [
    { reference: 'bul', levels: [{ level: 0, format: LevelFormat.BULLET, text: '\u2022', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] },
    { reference: 'num', levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 360 } } } }] },
  ] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1300, bottom: 1300, left: 1440, right: 1440 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Logistics Analytics Strategic Plan  |  Page ', size: 16, color: '777777' }), new TextRun({ children: [PageNumber.CURRENT], size: 16, color: '777777' })] })] }) },
    children: kids
  }]
});
Packer.toBuffer(doc).then(buf => { fs.writeFileSync('Logistics_Strategic_Plan.docx', buf); console.log('ok'); });
